from flask import Flask, render_template, request, redirect, url_for, flash
import sqlite3
from pathlib import Path
from recommender import recommend_careers

app = Flask(__name__)
app.secret_key = "change-this-secret-key"
DB_PATH = Path(__file__).with_name("career_app.db")

CAREERS = [
    {"title":"Python Developer","skills":"python programming problem solving APIs flask django SQL","interests":"software development backend automation","description":"Build applications, APIs and automation tools using Python.","learn":"Python, OOP, Flask/Django, SQL, Git"},
    {"title":"Frontend Developer","skills":"HTML CSS JavaScript responsive design UI UX React","interests":"web development design user interface","description":"Create responsive and interactive websites and user interfaces.","learn":"HTML, CSS, JavaScript, React, accessibility"},
    {"title":"Backend Developer","skills":"python java node SQL database APIs server security","interests":"software development backend systems","description":"Develop server-side logic, APIs and database-driven applications.","learn":"Python/Java/Node.js, REST APIs, SQL, authentication"},
    {"title":"Data Analyst","skills":"python SQL excel statistics data visualization power bi","interests":"data analysis business insights statistics","description":"Analyze data and communicate insights through reports and dashboards.","learn":"SQL, Excel, Python, statistics, Power BI/Tableau"},
    {"title":"Data Scientist","skills":"python machine learning statistics pandas numpy visualization SQL","interests":"data science research analytics prediction","description":"Use statistics and machine learning to discover patterns and make predictions.","learn":"Python, statistics, pandas, scikit-learn, SQL"},
    {"title":"Machine Learning Engineer","skills":"python machine learning deep learning tensorflow keras mathematics","interests":"artificial intelligence prediction automation","description":"Build, evaluate and deploy machine-learning models.","learn":"Python, ML, model evaluation, TensorFlow/PyTorch, APIs"},
    {"title":"Cybersecurity Analyst","skills":"networking linux security python cryptography monitoring","interests":"cybersecurity ethical hacking network security","description":"Monitor systems, identify vulnerabilities and help protect information.","learn":"Networking, Linux, security fundamentals, SIEM, scripting"},
    {"title":"Cloud Engineer","skills":"AWS Azure cloud linux networking docker deployment","interests":"cloud computing infrastructure devops","description":"Deploy and maintain scalable cloud infrastructure and services.","learn":"AWS/Azure, Linux, networking, Docker, CI/CD"},
    {"title":"Software Tester / QA Engineer","skills":"testing test cases automation selenium python debugging","interests":"software quality testing problem solving","description":"Find defects and ensure applications work reliably.","learn":"Manual testing, test cases, Selenium, API testing, Python"},
    {"title":"Android Developer","skills":"kotlin java android studio mobile UI APIs","interests":"mobile app development android","description":"Design and build Android applications.","learn":"Kotlin, Android Studio, Jetpack Compose, APIs, SQLite"}
]

def connect_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    with connect_db() as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS assessments (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                education TEXT NOT NULL,
                skills TEXT NOT NULL,
                interests TEXT NOT NULL,
                preferred_area TEXT NOT NULL,
                top_career TEXT NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/recommend", methods=["POST"])
def recommend():
    name = request.form.get("name", "").strip()
    education = request.form.get("education", "").strip()
    skills = request.form.get("skills", "").strip()
    interests = request.form.get("interests", "").strip()
    preferred_area = request.form.get("preferred_area", "").strip()

    if not all([name, education, skills, interests, preferred_area]):
        flash("Please complete all fields.")
        return redirect(url_for("home"))

    results = recommend_careers(skills, interests, CAREERS)
    top_career = results[0]["title"]

    with connect_db() as conn:
        conn.execute(
            """INSERT INTO assessments
            (name, education, skills, interests, preferred_area, top_career)
            VALUES (?, ?, ?, ?, ?, ?)""",
            (name, education, skills, interests, preferred_area, top_career)
        )

    return render_template("results.html", name=name, results=results,
                           skills=skills, interests=interests)

@app.route("/history")
def history():
    with connect_db() as conn:
        rows = conn.execute(
            "SELECT name, education, top_career, created_at FROM assessments ORDER BY id DESC LIMIT 30"
        ).fetchall()
    return render_template("history.html", rows=rows)

if __name__ == "__main__":
    init_db()
    app.run(debug=True)
