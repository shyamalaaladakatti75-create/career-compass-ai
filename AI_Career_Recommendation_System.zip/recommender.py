from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

def recommend_careers(skills, interests, careers):
    """Rank career profiles using TF-IDF cosine similarity.

    The user's skills receive 65% weight and interests receive 35% weight.
    Scores are relative matching indicators, not a guarantee of job suitability.
    """
    user_text = f"{skills} {skills} {interests}"
    documents = [user_text] + [
        f"{career['skills']} {career['interests']}" for career in careers
    ]
    vectorizer = TfidfVectorizer(stop_words="english", ngram_range=(1, 2))
    matrix = vectorizer.fit_transform(documents)
    similarities = cosine_similarity(matrix[0:1], matrix[1:]).flatten()

    output = []
    for career, score in zip(careers, similarities):
        output.append({
            **career,
            "score": round(float(score) * 100, 1)
        })
    return sorted(output, key=lambda item: item["score"], reverse=True)[:5]
