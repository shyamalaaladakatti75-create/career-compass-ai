# CareerCompass – AI-Based Career Recommendation System

A beginner-friendly academic project that recommends career paths from a student's skills and interests. It uses TF-IDF vectorization and cosine similarity to rank career profiles, Flask for the web application, and SQLite to save assessment history.

## Features
- Student profile form: name, education, skills, interests and preferred work area.
- Top five career recommendations with match similarity scores.
- Career descriptions and suggested skills to learn.
- SQLite assessment history.
- Responsive HTML/CSS interface.

## Requirements
- Python 3.10 or newer
- VS Code (recommended)
- Internet connection for the optional Google Fonts import; the app itself works without it.

## Setup in VS Code

1. Extract the ZIP file.
2. Open the `AI_Career_Recommendation_System` folder in VS Code.
3. Open Terminal → New Terminal.
4. Create a virtual environment:

   **Windows**
   ```bash
   py -m venv venv
   venv\Scripts\activate
   ```

   If `py` does not work, use `python` instead.

5. Install packages:
   ```bash
   python -m pip install -r requirements.txt
   ```

6. Start the application:
   ```bash
   python app.py
   ```

7. Open this address in your browser:
   `http://127.0.0.1:5000`

The SQLite database `career_app.db` is created automatically when the app starts. Assessments are saved when a user submits the form.

## Project structure

```text
AI_Career_Recommendation_System/
├── app.py
├── recommender.py
├── requirements.txt
├── career_app.db       # created automatically at runtime
├── README.md
├── templates/
│   ├── index.html
│   ├── results.html
│   └── history.html
└── static/
    └── style.css
```

## How the ML recommendation works

1. The user's skills and interests are combined into a text profile.
2. TF-IDF converts the user profile and each career profile into numerical vectors.
3. Cosine similarity measures how close the user profile is to each career profile.
4. The system sorts careers by similarity and displays the top five.

The displayed percentage is a similarity score, **not** a probability of employment or a validated aptitude score. The current version is a content-based recommendation prototype, not a model trained on labeled student outcomes.

## Database

Table: `assessments`

| Column | Purpose |
|---|---|
| id | Unique record ID |
| name | Student name |
| education | Education level |
| skills | Submitted skills |
| interests | Submitted interests |
| preferred_area | Work area preference |
| top_career | Highest-ranked career |
| created_at | Submission timestamp |

## Test data

Name: Ananya  
Education: Final-year undergraduate  
Skills: Python, SQL, statistics, pandas, machine learning  
Interests: data analysis, AI, prediction

Try other profiles too, such as HTML/CSS/JavaScript + web development, or Linux/networking + cybersecurity.

## Important academic explanation

- **Flask:** receives form data and serves pages.
- **Scikit-learn:** performs TF-IDF and cosine-similarity calculations.
- **SQLite:** stores submitted assessments.
- **HTML/CSS:** creates the user interface.
- **JavaScript:** can be added for client-side form enhancements.

## Future enhancements
- Add login and student/admin roles.
- Add a larger career dataset validated against real job descriptions.
- Include course and certification recommendations.
- Add a feedback form to evaluate recommendation quality.
- Add charts for skill gaps and career comparisons.
- Deploy with a production WSGI server and environment-based secret key.

## Security note
This is a local academic demo. Before public deployment, add authentication, CSRF protection, input length limits, privacy notice, secure secret management and production server configuration. Do not collect sensitive personal information.
